import { createContext, useContext, useEffect, useState } from 'react'
import { initialData } from './data'
import { today } from './utils'

const Ctx = createContext(null)
export const useStore = () => useContext(Ctx)

const KEY = 'scopelock_demo'

function load() {
  try {
    return JSON.parse(localStorage.getItem(KEY)) || structuredClone(initialData)
  } catch {
    return structuredClone(initialData)
  }
}

const auditEntry = (action, detail) => ({
  date: new Date().toISOString().slice(0, 16).replace('T', ' '),
  user: 'Alex Davis',
  action,
  detail,
})

export function StoreProvider({ children }) {
  const [data, setData] = useState(load)
  const [page, setPage] = useState('dashboard')
  const [modal, setModal] = useState(null) // { type, id? }
  const [toastMsg, setToastMsg] = useState('')

  useEffect(() => {
    try {
      localStorage.setItem(KEY, JSON.stringify(data))
    } catch {}
  }, [data])

  useEffect(() => {
    if (!toastMsg) return
    const t = setTimeout(() => setToastMsg(''), 2800)
    return () => clearTimeout(t)
  }, [toastMsg])

  const toast = setToastMsg
  const navigate = (p) => {
    setPage(p)
    window.scrollTo(0, 0)
  }
  const openModal = (type, id) => setModal({ type, id })
  const closeModal = () => setModal(null)
  const projectName = (id) => data.projects.find((p) => p.id === id)?.name || 'New project'

  const addProject = (p) => {
    setData((d) => ({
      ...d,
      projects: [{ ...p, id: Date.now(), progress: 0, scope: 'Version 1.0' }, ...d.projects],
      audit: [auditEntry('Project created', `${p.name} · ${p.client}`), ...d.audit],
    }))
  }

  const addChange = (c) => {
    setData((d) => ({
      ...d,
      changes: [{ ...c, id: Date.now(), status: 'Pending', date: today() }, ...d.changes],
      audit: [
        auditEntry('Change request submitted', `${c.title} · ${d.projects.find((p) => p.id === c.project)?.name}`),
        ...d.audit,
      ],
    }))
  }

  const decideChange = (id, status) => {
    setData((d) => {
      const c = d.changes.find((x) => x.id === id)
      if (!c || c.status !== 'Pending') return d
      const pname = d.projects.find((p) => p.id === c.project)?.name
      let { projects, agreements, milestones } = d

      if (status === 'Approved') {
        projects = d.projects.map((p) => {
          if (p.id !== c.project) return p
          const dt = new Date(p.deadline + 'T12:00:00')
          dt.setDate(dt.getDate() + c.days)
          return { ...p, budget: p.budget + c.cost, deadline: dt.toISOString().slice(0, 10), scope: 'Version 2.0' }
        })
        const firstAgr = d.agreements.find((a) => a.project === c.project)
        agreements = d.agreements.map((a) =>
          a === firstAgr
            ? { ...a, amount: a.amount + c.cost, version: (Number(a.version) + 0.1).toFixed(1), date: today() }
            : a
        )
        milestones = [
          ...d.milestones,
          {
            title: 'Approved change: ' + c.title,
            project: c.project,
            date: new Date(Date.now() + c.days * 86400000).toISOString().slice(0, 10),
            owner: 'Delivery team',
            status: 'Upcoming',
          },
        ]
      }

      return {
        ...d,
        changes: d.changes.map((x) => (x.id === id ? { ...x, status } : x)),
        projects,
        agreements,
        milestones,
        audit: [
          auditEntry(
            'Change request ' + status.toLowerCase(),
            `${c.title} · ${pname}` + (status === 'Approved' ? ` · ₹${c.cost.toLocaleString('en-IN')} · +${c.days} days` : '')
          ),
          ...d.audit,
        ],
      }
    })
    toast(status === 'Approved' ? 'Approved: budget and deadline updated' : 'Rejected: baseline unchanged')
  }

  const addRequirement = (r) => {
    setData((d) => ({
      ...d,
      requirements: [...d.requirements, r],
      audit: [auditEntry('Requirement added', r.title), ...d.audit],
    }))
  }

  const generateAgreement = () => {
    setData((d) => {
      const p = d.projects[0]
      if (!p) return d
      const id = 'AGR-' + new Date().getFullYear() + '-' + String(d.agreements.length + 1).padStart(3, '0')
      return {
        ...d,
        agreements: [{ id, project: p.id, version: '1.0', amount: p.budget, date: today(), status: 'Draft' }, ...d.agreements],
        audit: [auditEntry('Agreement generated', `${id} · ${p.name}`), ...d.audit],
      }
    })
    toast('Draft agreement created')
  }

  const resetData = () => {
    localStorage.removeItem(KEY)
    setData(structuredClone(initialData))
    toast('Demo data reset')
  }

  const value = {
    data, page, navigate, modal, openModal, closeModal, toastMsg, toast,
    projectName, addProject, addChange, decideChange, addRequirement, generateAgreement, resetData,
  }
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>
}
