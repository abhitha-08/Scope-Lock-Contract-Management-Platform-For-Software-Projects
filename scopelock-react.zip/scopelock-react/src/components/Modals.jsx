import { useStore } from '../store'
import { money } from '../utils'
import { StatusTag } from './ui'

function Modal({ children }) {
  const { closeModal } = useStore()
  return (
    <div className="modal-bg" onClick={(e) => e.target === e.currentTarget && closeModal()}>
      <div className="modal">{children}</div>
    </div>
  )
}

function ProjectForm() {
  const { addProject, closeModal, toast, navigate } = useStore()
  const submit = (e) => {
    e.preventDefault()
    const f = new FormData(e.target)
    addProject({
      name: f.get('name'), client: f.get('client'), deadline: f.get('deadline'),
      budget: +f.get('budget'), status: f.get('status'),
    })
    closeModal()
    toast('Project created successfully')
    navigate('projects')
  }
  return (
    <>
      <h2>Create a project</h2>
      <p className="sub">Set up the project baseline.</p>
      <form className="formgrid" onSubmit={submit}>
        <div className="field full"><label>Project name *</label><input name="name" required placeholder="e.g. Customer Portal" /></div>
        <div className="field"><label>Client *</label><input name="client" required placeholder="Client company" /></div>
        <div className="field"><label>Expected deadline *</label><input name="deadline" type="date" required /></div>
        <div className="field"><label>Base budget (₹) *</label><input name="budget" type="number" min="0" required placeholder="250000" /></div>
        <div className="field"><label>Initial status</label><select name="status"><option>Planning</option><option>Active</option></select></div>
        <div className="field full"><label>Project description</label><textarea name="desc" placeholder="Objectives and deliverables" /></div>
        <div className="modal-actions full">
          <button type="button" className="secondary" onClick={closeModal}>Cancel</button>
          <button className="primary">Create project</button>
        </div>
      </form>
    </>
  )
}

function ChangeForm() {
  const { data, addChange, closeModal, toast } = useStore()
  const submit = (e) => {
    e.preventDefault()
    const f = new FormData(e.target)
    addChange({
      title: f.get('title'), project: +f.get('project'), requester: f.get('requester') || 'Client',
      description: f.get('description'), cost: +f.get('cost'), days: +f.get('days'),
    })
    closeModal()
    toast('Request submitted for approval')
  }
  return (
    <>
      <h2>New change request</h2>
      <p className="sub">Propose additional work for formal review.</p>
      <form className="formgrid" onSubmit={submit}>
        <div className="field full"><label>Request title *</label><input name="title" required placeholder="Describe the feature" /></div>
        <div className="field"><label>Project *</label>
          <select name="project">{data.projects.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}</select>
        </div>
        <div className="field"><label>Requested by</label><input name="requester" defaultValue="Client" /></div>
        <div className="field full"><label>Description</label><textarea name="description" required placeholder="What needs to change and why?" /></div>
        <div className="field"><label>Additional cost (₹) *</label><input name="cost" type="number" min="0" required /></div>
        <div className="field"><label>Timeline impact (days) *</label><input name="days" type="number" min="0" required /></div>
        <div className="modal-actions full">
          <button type="button" className="secondary" onClick={closeModal}>Cancel</button>
          <button className="primary">Submit request</button>
        </div>
      </form>
    </>
  )
}

function ScopeForm() {
  const { data, addRequirement, closeModal, toast } = useStore()
  const submit = (e) => {
    e.preventDefault()
    const f = new FormData(e.target)
    addRequirement({
      title: f.get('title'), project: +f.get('project'), priority: f.get('priority'),
      hours: +f.get('hours'), status: f.get('status'),
    })
    closeModal()
    toast('Requirement added')
  }
  return (
    <>
      <h2>Add requirement</h2>
      <p className="sub">Add an item to the scope baseline.</p>
      <form className="formgrid" onSubmit={submit}>
        <div className="field full"><label>Requirement *</label><input name="title" required /></div>
        <div className="field"><label>Project</label>
          <select name="project">{data.projects.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}</select>
        </div>
        <div className="field"><label>Priority</label>
          <select name="priority" defaultValue="Medium"><option>High</option><option>Medium</option><option>Low</option></select>
        </div>
        <div className="field"><label>Estimated effort (hours)</label><input name="hours" type="number" min="0" required /></div>
        <div className="field"><label>Scope status</label><select name="status"><option>Included</option><option>Excluded</option></select></div>
        <div className="modal-actions full">
          <button type="button" className="secondary" onClick={closeModal}>Cancel</button>
          <button className="primary">Add requirement</button>
        </div>
      </form>
    </>
  )
}

function ProjectView({ id }) {
  const { data, closeModal, navigate } = useStore()
  const p = data.projects.find((x) => x.id === id)
  if (!p) return null
  return (
    <>
      <h2>{p.name}</h2>
      <p className="sub">{p.client} · <StatusTag s={p.status} /></p>
      <div className="grid stats" style={{ gridTemplateColumns: '1fr 1fr' }}>
        <div className="card"><div className="muted">Approved budget</div><div className="stat-number" style={{ fontSize: 22 }}>{money(p.budget)}</div></div>
        <div className="card"><div className="muted">Completion</div><div className="stat-number" style={{ fontSize: 22 }}>{p.progress}%</div></div>
      </div>
      <p><strong>Deadline:</strong> {p.deadline}</p>
      <p><strong>Scope baseline:</strong> {p.scope}</p>
      <p className="muted">Demo project details. Change requests require approval before the approved baseline changes.</p>
      <div className="modal-actions">
        <button className="secondary" onClick={closeModal}>Close</button>
        <button className="primary" onClick={() => { closeModal(); navigate('changes') }}>View change requests</button>
      </div>
    </>
  )
}

function ChangeView({ id }) {
  const { data, closeModal, projectName } = useStore()
  const c = data.changes.find((x) => x.id === id)
  if (!c) return null
  return (
    <>
      <h2>{c.title}</h2>
      <p className="sub">{projectName(c.project)} · <StatusTag s={c.status} /></p>
      <p>{c.description}</p>
      <div className="grid stats" style={{ gridTemplateColumns: '1fr 1fr' }}>
        <div className="card"><div className="muted">Proposed additional cost</div><div className="stat-number" style={{ fontSize: 22 }}>{money(c.cost)}</div></div>
        <div className="card"><div className="muted">Timeline impact</div><div className="stat-number" style={{ fontSize: 22 }}>+{c.days} days</div></div>
      </div>
      <p><strong>Requested by:</strong> {c.requester}</p>
      <p><strong>Submitted:</strong> {c.date}</p>
      <div className="modal-actions"><button className="secondary" onClick={closeModal}>Close</button></div>
    </>
  )
}

function printAgreement(a, p) {
  const w = window.open('', '_blank')
  if (!w) return
  w.document.write(`<html><head><title>${a.id}</title><style>body{font:16px Arial;max-width:800px;margin:50px auto;line-height:1.6}h1{color:#10213f}hr{border:0;border-top:1px solid #ddd}</style></head><body><h1>ScopeLock — Project Agreement</h1><p><b>Agreement ID:</b> ${a.id}</p><p><b>Project:</b> ${p.name}</p><p><b>Client:</b> ${p.client}</p><p><b>Version:</b> ${a.version}</p><hr><h3>Approved baseline</h3><p><b>Project budget:</b> ${money(a.amount)}</p><p><b>Expected deadline:</b> ${p.deadline}</p><p><b>Scope version:</b> ${p.scope}</p><p>This demo agreement summarizes project details and is not legal advice or a certified digital signature.</p><br><p>Client acceptance: ____________________</p><p>Authorized representative: ____________________</p><script>window.print()<\/script></body></html>`)
  w.document.close()
}

function AgreementView({ id }) {
  const { data, closeModal } = useStore()
  const a = data.agreements.find((x) => x.id === id)
  const p = a && data.projects.find((x) => x.id === a.project)
  if (!a || !p) return null
  return (
    <>
      <h2>Project agreement</h2>
      <p className="sub">{a.id} · Version {a.version}</p>
      <div className="note">DEMO DOCUMENT — not a legally certified electronic signature.</div>
      <p><strong>Project:</strong> {p.name}</p>
      <p><strong>Client:</strong> {p.client}</p>
      <p><strong>Approved budget:</strong> {money(a.amount)}</p>
      <p><strong>Deadline:</strong> {p.deadline}</p>
      <p><strong>Scope version:</strong> {p.scope}</p>
      <p><strong>Status:</strong> {a.status}</p>
      <div className="modal-actions">
        <button className="secondary" onClick={closeModal}>Close</button>
        <button className="primary" onClick={() => printAgreement(a, p)}>Print / Save PDF</button>
      </div>
    </>
  )
}

export function ModalHost() {
  const { modal } = useStore()
  if (!modal) return null
  const views = {
    project: <ProjectForm />,
    change: <ChangeForm />,
    scope: <ScopeForm />,
    viewProject: <ProjectView id={modal.id} />,
    viewChange: <ChangeView id={modal.id} />,
    viewAgreement: <AgreementView id={modal.id} />,
  }
  return <Modal>{views[modal.type]}</Modal>
}

export function Toast() {
  const { toastMsg } = useStore()
  return toastMsg ? <div className="toast">{toastMsg}</div> : null
}
