import { useStore } from '../store'

export const NAV = [
  { id: 'dashboard', label: 'Dashboard', icon: '▦', group: 'WORKSPACE' },
  { id: 'projects', label: 'Projects', icon: '▣' },
  { id: 'scope', label: 'Scope management', icon: '☷' },
  { id: 'changes', label: 'Change requests', icon: '↻', badge: true },
  { id: 'agreements', label: 'Agreements', icon: '▤' },
  { id: 'timeline', label: 'Timeline & milestones', icon: '◷' },
  { id: 'pricing', label: 'Pricing & budget', icon: '＄' },
  { id: 'reports', label: 'Reports & analytics', icon: '▥', group: 'INSIGHTS' },
  { id: 'audit', label: 'Audit trail', icon: '◉' },
  { id: 'settings', label: 'Settings', icon: '⚙' },
]

export function Sidebar() {
  const { page, navigate, data } = useStore()
  const pending = data.changes.filter((c) => c.status === 'Pending').length
  return (
    <aside className="sidebar">
      <div className="brand">Scope<span>Lock</span><small>SCOPE &amp; CONTRACTS</small></div>
      {NAV.map((n) => (
        <div key={n.id}>
          {n.group && <div className="label" style={n.group === 'INSIGHTS' ? { marginTop: 16 } : undefined}>{n.group}</div>}
          <div className={`nav ${page === n.id ? 'active' : ''}`} onClick={() => navigate(n.id)}>
            <span className="ico">{n.icon}</span> {n.label}
            {n.badge && <span className="tag amber" style={{ marginLeft: 'auto' }}>{pending}</span>}
          </div>
        </div>
      ))}
      <div className="side-foot">● Demo workspace<br /><span style={{ fontSize: 10 }}>Demo data is saved in this browser.</span></div>
    </aside>
  )
}

export function Topbar() {
  const { page } = useStore()
  const current = NAV.find((n) => n.id === page)?.label
  return (
    <header className="topbar">
      <div>
        <span className="mobile-menu">☰ &nbsp;</span>
        <span className="crumb">Workspace / </span>
        <strong>{current}</strong>
      </div>
      <div className="top-right">
        <span className="tag blue">DEMO MODE</span>
        <span style={{ fontSize: 18 }}>♧</span>
        <div className="avatar">AD</div>
        <div>
          <strong style={{ fontSize: 12 }}>Alex Davis</strong>
          <div className="muted" style={{ fontSize: 10 }}>Administrator</div>
        </div>
      </div>
    </header>
  )
}
