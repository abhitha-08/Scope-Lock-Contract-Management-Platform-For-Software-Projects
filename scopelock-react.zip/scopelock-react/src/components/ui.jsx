import { STATUS_COLORS } from '../utils'

export function StatusTag({ s }) {
  return <span className={`tag ${STATUS_COLORS[s] || ''}`}>{s}</span>
}

export function Progress({ value }) {
  return (
    <div className="progress-row">
      <div className="progress"><span style={{ width: `${value}%` }} /></div>
      {value}%
    </div>
  )
}

export function StatCard({ label, icon, value, note }) {
  return (
    <div className="card">
      <div className="stat-top">{label} {icon && <span className="stat-icon">{icon}</span>}</div>
      <div className="stat-number">{value}</div>
      <div className="stat-note">{note}</div>
    </div>
  )
}

export function PageHead({ title, sub, children }) {
  return (
    <div className="pagehead">
      <div><h1>{title}</h1><p className="sub">{sub}</p></div>
      {children}
    </div>
  )
}

export function BarRow({ label, value, percent, color, valueWidth, labelWidth }) {
  const style = labelWidth ? { gridTemplateColumns: `${labelWidth} 1fr ${valueWidth || '40px'}` } : undefined
  return (
    <div className="barrow" style={style}>
      <span>{label}</span>
      <div className="bar"><span style={{ width: `${percent}%`, background: color }} /></div>
      <strong>{value}</strong>
    </div>
  )
}
