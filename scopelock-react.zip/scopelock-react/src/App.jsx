import { StoreProvider, useStore } from './store'
import { Sidebar, Topbar } from './components/Layout'
import { ModalHost, Toast } from './components/Modals'
import Dashboard from './pages/Dashboard'
import Projects from './pages/Projects'
import Scope from './pages/Scope'
import Changes from './pages/Changes'
import Agreements from './pages/Agreements'
import Timeline from './pages/Timeline'
import Pricing from './pages/Pricing'
import Reports from './pages/Reports'
import Audit from './pages/Audit'
import Settings from './pages/Settings'

const PAGES = {
  dashboard: Dashboard,
  projects: Projects,
  scope: Scope,
  changes: Changes,
  agreements: Agreements,
  timeline: Timeline,
  pricing: Pricing,
  reports: Reports,
  audit: Audit,
  settings: Settings,
}

function CurrentPage() {
  const { page } = useStore()
  const Page = PAGES[page] || Dashboard
  return <Page />
}

export default function App() {
  return (
    <StoreProvider>
      <div className="layout">
        <Sidebar />
        <main className="main">
          <Topbar />
          <div className="content">
            <CurrentPage />
          </div>
        </main>
      </div>
      <ModalHost />
      <Toast />
    </StoreProvider>
  )
}
