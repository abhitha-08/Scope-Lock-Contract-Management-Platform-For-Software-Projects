export const money = (n) => '₹' + Number(n).toLocaleString('en-IN')

export const shortMoney = (n) =>
  n >= 100000 ? (n / 100000).toFixed(1) + 'L' : n >= 1000 ? Math.round(n / 1000) + 'K' : String(n)

export const STATUS_COLORS = {
  Active: 'green',
  Accepted: 'green',
  Approved: 'green',
  Completed: 'green',
  Included: 'green',
  Pending: 'amber',
  'Awaiting client': 'amber',
  'At risk': 'red',
  Rejected: 'red',
  Planning: 'blue',
  Draft: 'blue',
  'In progress': 'blue',
  Upcoming: 'blue',
}

export const today = () => new Date().toISOString().slice(0, 10)

export function downloadFile(name, content) {
  const a = document.createElement('a')
  a.href = URL.createObjectURL(new Blob([content], { type: 'text/csv' }))
  a.download = name
  a.click()
  URL.revokeObjectURL(a.href)
}

export function toCSV(rows) {
  return rows.map((r) => r.map((v) => '"' + String(v).replaceAll('"', '""') + '"').join(',')).join('\n')
}
