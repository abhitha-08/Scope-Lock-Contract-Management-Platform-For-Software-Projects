export const initialData = {
  projects: [
    { id: 1, name: 'E-commerce Platform', client: 'Acme Retail', status: 'Active', deadline: '2026-11-12', budget: 480000, progress: 72, scope: 'Version 2.1' },
    { id: 2, name: 'Customer Portal', client: 'BrightPath Ltd.', status: 'At risk', deadline: '2026-10-28', budget: 325000, progress: 48, scope: 'Version 1.3' },
    { id: 3, name: 'Inventory Management', client: 'Northstar Goods', status: 'Active', deadline: '2026-12-04', budget: 560000, progress: 61, scope: 'Version 1.0' },
    { id: 4, name: 'Mobile Banking UI', client: 'FinEdge', status: 'Planning', deadline: '2026-12-20', budget: 315000, progress: 15, scope: 'Version 1.0' },
    { id: 5, name: 'Analytics Dashboard', client: 'Acme Retail', status: 'Completed', deadline: '2026-09-30', budget: 260000, progress: 100, scope: 'Version 2.0' },
  ],
  changes: [
    { id: 101, title: 'Add multi-currency checkout', project: 1, requester: 'Acme Retail', cost: 45000, days: 5, status: 'Pending', date: '2026-10-15', description: 'Support three additional checkout currencies.' },
    { id: 102, title: 'Advanced role permissions', project: 2, requester: 'BrightPath Ltd.', cost: 28000, days: 3, status: 'Pending', date: '2026-10-14', description: 'Add custom permission groups for portal users.' },
    { id: 103, title: 'Export reports to Excel', project: 3, requester: 'Northstar Goods', cost: 62000, days: 4, status: 'Approved', date: '2026-10-10', description: 'Export inventory and stock reports to Excel.' },
    { id: 104, title: 'Dark mode theme', project: 1, requester: 'Acme Retail', cost: 18000, days: 2, status: 'Rejected', date: '2026-10-08', description: 'Add a dark theme across the platform.' },
  ],
  requirements: [
    { title: 'User authentication & profiles', project: 1, priority: 'High', hours: 32, status: 'Included' },
    { title: 'Product catalogue and search', project: 1, priority: 'High', hours: 54, status: 'Included' },
    { title: 'Checkout and payment integration', project: 1, priority: 'High', hours: 48, status: 'Included' },
    { title: 'Role-based access controls', project: 2, priority: 'Medium', hours: 24, status: 'Included' },
    { title: 'Inventory alerts', project: 3, priority: 'Medium', hours: 18, status: 'Included' },
  ],
  agreements: [
    { id: 'AGR-2026-001', project: 1, version: '2.1', amount: 498000, date: '2026-10-12', status: 'Accepted' },
    { id: 'AGR-2026-002', project: 2, version: '1.3', amount: 325000, date: '2026-10-08', status: 'Awaiting client' },
    { id: 'AGR-2026-003', project: 3, version: '1.0', amount: 560000, date: '2026-10-01', status: 'Accepted' },
    { id: 'AGR-2026-004', project: 4, version: '1.0', amount: 315000, date: '2026-09-28', status: 'Draft' },
  ],
  milestones: [
    { title: 'Checkout integration', project: 1, date: '2026-10-22', owner: 'Dev team', status: 'In progress' },
    { title: 'Client UAT review', project: 2, date: '2026-10-20', owner: 'Client + PM', status: 'At risk' },
    { title: 'Inventory reporting', project: 3, date: '2026-10-25', owner: 'Dev team', status: 'Upcoming' },
    { title: 'Design sign-off', project: 4, date: '2026-10-30', owner: 'Client', status: 'Upcoming' },
  ],
  audit: [
    { date: '2026-10-15 09:42', user: 'Alex Davis', action: 'Change request submitted', detail: 'Add multi-currency checkout · E-commerce Platform' },
    { date: '2026-10-14 16:20', user: 'Mia Chen', action: 'Scope version updated', detail: 'Customer Portal · Version 1.3' },
    { date: '2026-10-12 11:08', user: 'Alex Davis', action: 'Agreement accepted', detail: 'E-commerce Platform · Agreement AGR-2026-001' },
    { date: '2026-10-10 14:35', user: 'Jordan Lee', action: 'Change request approved', detail: 'Export reports to Excel · Inventory Management' },
  ],
}
