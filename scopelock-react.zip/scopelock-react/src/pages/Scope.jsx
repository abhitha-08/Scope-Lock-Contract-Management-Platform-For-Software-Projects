import { useStore } from '../store'
import { StatusTag, PageHead } from '../components/ui'

export default function Scope() {
  const { data, openModal, projectName } = useStore()
  const priorityTag = (p) => (p === 'High' ? 'At risk' : p === 'Medium' ? 'Planning' : 'Active')

  return (
    <>
      <PageHead title="Scope management" sub="Keep approved deliverables and exclusions clearly documented.">
        <button className="primary" onClick={() => openModal('scope')}>＋ Add requirement</button>
      </PageHead>

      <div className="note">🔒 Scope baseline: approved requirements are the source of truth. New work must go through a client-approved change request.</div>

      <div className="card">
        <div className="card-title"><h2>Requirements &amp; deliverables</h2><span className="tag blue">Version 1.0</span></div>
        <div className="table-wrap">
          <table>
            <thead><tr><th>Requirement</th><th>Project</th><th>Priority</th><th>Effort</th><th>Scope status</th></tr></thead>
            <tbody>
              {data.requirements.map((r, i) => (
                <tr key={i}>
                  <td><strong>{r.title}</strong></td>
                  <td>{projectName(r.project)}</td>
                  <td><StatusTag s={priorityTag(r.priority)} /></td>
                  <td>{r.hours} hrs</td>
                  <td><StatusTag s={r.status} /></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </>
  )
}
