import { useStore } from '../store'
import { money } from '../utils'
import { StatusTag, PageHead } from '../components/ui'

export default function Agreements() {
  const { data, projectName, generateAgreement, openModal } = useStore()
  return (
    <>
      <PageHead title="Agreements" sub="Track approved terms and agreement versions.">
        <button className="primary" onClick={generateAgreement}>＋ Generate agreement</button>
      </PageHead>

      <div className="card table-wrap">
        <table>
          <thead>
            <tr><th>Agreement</th><th>Project</th><th>Version</th><th>Amount</th><th>Last updated</th><th>Status</th><th></th></tr>
          </thead>
          <tbody>
            {data.agreements.map((a) => (
              <tr key={a.id}>
                <td><strong>{a.id}</strong></td>
                <td>{projectName(a.project)}</td>
                <td>v{a.version}</td>
                <td>{money(a.amount)}</td>
                <td>{a.date}</td>
                <td><StatusTag s={a.status} /></td>
                <td><button className="secondary small" onClick={() => openModal('viewAgreement', a.id)}>View</button></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  )
}
