import { useStore } from '../store'
import { money, shortMoney } from '../utils'
import { StatusTag, Progress, StatCard, PageHead, BarRow } from '../components/ui'

export default function Dashboard() {
  const { data, navigate, openModal, projectName } = useStore()
  const active = data.projects.filter((p) => p.status === 'Active' || p.status === 'At risk').length
  const pendingChanges = data.changes.filter((c) => c.status === 'Pending')
  const base = data.projects.reduce((a, p) => a + p.budget, 0)
  const approved = data.changes.filter((c) => c.status === 'Approved').reduce((a, c) => a + c.cost, 0)

  const counts = ['Pending', 'Approved', 'Rejected', 'Implemented'].map((s) => ({
    s, n: data.changes.filter((c) => c.status === s).length,
  }))
  const max = Math.max(1, ...counts.map((x) => x.n))
  const colorOf = { Rejected: '#e56c75', Approved: '#20a37a', Pending: '#e0a32c' }

  return (
    <>
      <PageHead title="Good morning, Alex 👋" sub="Here's what's happening across your projects today.">
        <button className="primary" onClick={() => openModal('project')}>＋ New project</button>
      </PageHead>

      <div className="grid stats">
        <StatCard label="Total projects" icon="▣" value={data.projects.length} note="Across your workspace" />
        <StatCard label="Active projects" icon="↗" value={active} note="Currently in delivery" />
        <StatCard label="Pending approvals" icon="◷" value={pendingChanges.length} note="Awaiting client response" />
        <StatCard label="Revised budget" icon="＄" value={'₹' + shortMoney(base + approved)} note="Approved project value" />
      </div>

      <div className="grid two">
        <div className="card">
          <div className="card-title">
            <div><h2>Project overview</h2><p>Current delivery status</p></div>
            <button className="secondary" onClick={() => navigate('projects')}>View all →</button>
          </div>
          <div className="table-wrap">
            <table>
              <thead><tr><th>Project</th><th>Status</th><th>Progress</th><th>Budget</th></tr></thead>
              <tbody>
                {data.projects.slice(0, 4).map((p) => (
                  <tr key={p.id}>
                    <td><div className="project-name">{p.name}</div><div className="muted">{p.client}</div></td>
                    <td><StatusTag s={p.status} /></td>
                    <td><Progress value={p.progress} /></td>
                    <td>{money(p.budget)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className="card">
          <div className="card-title">
            <div><h2>Needs your attention</h2><p>Items waiting for action</p></div>
            <span className="tag amber">{pendingChanges.length} pending</span>
          </div>
          {pendingChanges.length ? pendingChanges.map((c) => (
            <div className="activity" key={c.id}>
              <div className="dot" style={{ background: '#d89b25' }} />
              <div style={{ flex: 1 }}>
                <strong>{c.title}</strong>
                <p>{projectName(c.project)} · {money(c.cost)} · +{c.days} days</p>
                <button className="secondary small" onClick={() => navigate('changes')}>Review request →</button>
              </div>
            </div>
          )) : <div className="empty">All caught up — no pending approvals.</div>}
        </div>

        <div className="card">
          <div className="card-title">
            <div><h2>Change request status</h2><p>Requests in this workspace</p></div>
            <button className="secondary" onClick={() => navigate('changes')}>Open requests →</button>
          </div>
          {counts.map((x) => (
            <BarRow key={x.s} label={x.s} value={x.n} percent={(x.n / max) * 100} color={colorOf[x.s] || '#3867e8'} />
          ))}
        </div>

        <div className="card">
          <div className="card-title">
            <div><h2>Recent activity</h2><p>Latest recorded project events</p></div>
            <button className="secondary" onClick={() => navigate('audit')}>Audit trail →</button>
          </div>
          {data.audit.slice(0, 4).map((a, i) => (
            <div className="activity" key={i}>
              <div className="dot" />
              <div><strong>{a.action}</strong><p>{a.detail}</p><p>{a.date} · {a.user}</p></div>
            </div>
          ))}
        </div>
      </div>
    </>
  )
}
