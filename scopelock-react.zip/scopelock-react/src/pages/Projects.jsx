import { useState } from 'react'
import { useStore } from '../store'
import { money } from '../utils'
import { StatusTag, Progress, PageHead } from '../components/ui'

export default function Projects() {
  const { data, openModal } = useStore()
  const [q, setQ] = useState('')
  const [filter, setFilter] = useState('')

  const list = data.projects.filter(
    (p) => (p.name + ' ' + p.client).toLowerCase().includes(q.toLowerCase()) && (!filter || p.status === filter)
  )

  return (
    <>
      <PageHead title="Projects" sub="Manage scope, contracts, budgets, and delivery.">
        <button className="primary" onClick={() => openModal('project')}>＋ Create project</button>
      </PageHead>

      <div className="toolbar">
        <input placeholder="Search projects..." value={q} onChange={(e) => setQ(e.target.value)} />
        <select value={filter} onChange={(e) => setFilter(e.target.value)}>
          <option value="">All statuses</option>
          <option>Active</option>
          <option>At risk</option>
          <option>Completed</option>
          <option>Planning</option>
        </select>
      </div>

      <div className="card table-wrap">
        <table>
          <thead>
            <tr><th>Project</th><th>Client</th><th>Status</th><th>Deadline</th><th>Budget</th><th>Progress</th><th></th></tr>
          </thead>
          <tbody>
            {list.length ? list.map((p) => (
              <tr key={p.id}>
                <td><div className="project-name">{p.name}</div><div className="muted">{p.scope}</div></td>
                <td>{p.client}</td>
                <td><StatusTag s={p.status} /></td>
                <td>{p.deadline}</td>
                <td>{money(p.budget)}</td>
                <td><Progress value={p.progress} /></td>
                <td><button className="secondary small" onClick={() => openModal('viewProject', p.id)}>View</button></td>
              </tr>
            )) : (
              <tr><td colSpan="7" className="empty">No projects match your search.</td></tr>
            )}
          </tbody>
        </table>
      </div>
    </>
  )
}
