import { useStore } from '../store'
import { downloadFile, toCSV } from '../utils'
import { PageHead } from '../components/ui'

export default function Audit() {
  const { data } = useStore()

  const exportCSV = () => {
    const rows = [
      ['Date', 'User', 'Action', 'Details'],
      ...data.audit.map((a) => [a.date, a.user, a.action, a.detail]),
    ]
    downloadFile('scopelock-audit-trail.csv', toCSV(rows))
  }

  return (
    <>
      <PageHead title="Audit trail" sub="Chronological record of important actions in this demo.">
        <button className="secondary" onClick={exportCSV}>⇩ Export CSV</button>
      </PageHead>

      <div className="card">
        {data.audit.map((a, i) => (
          <div className="activity" key={i}>
            <div className="dot" />
            <div><strong>{a.action}</strong><p>{a.detail}</p><p>{a.date} · {a.user}</p></div>
          </div>
        ))}
      </div>
    </>
  )
}
