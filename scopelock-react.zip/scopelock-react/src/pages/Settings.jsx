import { useStore } from '../store'
import { PageHead } from '../components/ui'

export default function Settings() {
  const { toast, resetData } = useStore()
  return (
    <>
      <PageHead title="Workspace settings" sub="Configure your organization and demo workspace." />

      <div className="grid two">
        <div className="card">
          <div className="card-title"><h2>Organization</h2></div>
          <div className="field">
            <label>Organization name</label>
            <input defaultValue="ScopeLock Demo Studio" />
          </div>
          <div className="field" style={{ marginTop: 13 }}>
            <label>Default currency</label>
            <select>
              <option>INR — Indian Rupee (₹)</option>
              <option>USD — US Dollar ($)</option>
            </select>
          </div>
          <div style={{ marginTop: 16 }}>
            <button className="primary" onClick={() => toast('Settings saved in this demo session.')}>Save settings</button>
          </div>
        </div>

        <div className="card">
          <div className="card-title"><h2>Demo data</h2><span className="tag amber">Local only</span></div>
          <p className="muted">
            This prototype stores changes in this browser using local storage. It does not connect to Supabase,
            send emails, or create legally certified signatures.
          </p>
          <button
            className="danger"
            onClick={() => window.confirm('Reset demo data to the original sample?') && resetData()}
          >
            Reset demo data
          </button>
        </div>
      </div>
    </>
  )
}
