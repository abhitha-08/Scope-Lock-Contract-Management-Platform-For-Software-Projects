import { useState } from 'react'
import { useStore } from '../store'
import { money } from '../utils'
import { StatusTag, PageHead } from '../components/ui'

const FILTERS = ['All', 'Pending', 'Approved', 'Rejected']

export default function Changes() {
  const { data, openModal, projectName, decideChange } = useStore()
  const [filter, setFilter] = useState('All')

  const list = data.changes.filter((c) => filter === 'All' || c.status === filter)

  const decide = (c, status) => {
    const msg = `${status} "${c.title}"? ${
      status === 'Approved'
        ? 'The approved budget and project timeline will be updated.'
        : 'The original agreement, budget, and timeline will remain unchanged.'
    }`
    if (window.confirm(msg)) decideChange(c.id, status)
  }

  return (
    <>
      <PageHead title="Change requests" sub="Review additional work before it affects the approved agreement.">
        <button className="primary" onClick={() => openModal('change')}>＋ New request</button>
      </PageHead>

      <div className="note">⚠️ Only client-approved changes update the official budget and timeline. Rejected or deferred requests leave the baseline unchanged.</div>

      <div className="pill-tabs">
        {FILTERS.map((f) => (
          <button key={f} className={filter === f ? 'active' : ''} onClick={() => setFilter(f)}>
            {f === 'All' ? 'All requests' : f}
          </button>
        ))}
      </div>

      <div className="card table-wrap">
        <table>
          <thead>
            <tr><th>Request</th><th>Project</th><th>Requested by</th><th>Cost impact</th><th>Timeline</th><th>Status</th><th>Actions</th></tr>
          </thead>
          <tbody>
            {list.length ? list.map((c) => (
              <tr key={c.id}>
                <td><div className="project-name">{c.title}</div><div className="muted">{c.date}</div></td>
                <td>{projectName(c.project)}</td>
                <td>{c.requester}</td>
                <td>{money(c.cost)}</td>
                <td>+{c.days} days</td>
                <td><StatusTag s={c.status} /></td>
                <td>
                  {c.status === 'Pending' ? (
                    <>
                      <button className="primary small" onClick={() => decide(c, 'Approved')}>Approve</button>{' '}
                      <button className="secondary small" onClick={() => decide(c, 'Rejected')}>Reject</button>
                    </>
                  ) : (
                    <button className="secondary small" onClick={() => openModal('viewChange', c.id)}>Details</button>
                  )}
                </td>
              </tr>
            )) : (
              <tr><td colSpan="7" className="empty">No requests in this category.</td></tr>
            )}
          </tbody>
        </table>
      </div>
    </>
  )
}
