import { useStore } from '../store'
import { StatusTag, PageHead } from '../components/ui'

export default function Timeline() {
  const { data, projectName, toast } = useStore()
  return (
    <>
      <PageHead title="Timeline & milestones" sub="See planned delivery dates and approved changes.">
        <button className="secondary" onClick={() => toast('Timeline export is available in the full production setup.')}>⇩ Export timeline</button>
      </PageHead>

      <div className="card">
        <div className="card-title"><h2>Upcoming milestones</h2><span className="tag blue">Current plan</span></div>
        <div className="table-wrap">
          <table>
            <thead><tr><th>Milestone</th><th>Project</th><th>Due date</th><th>Owner</th><th>Status</th></tr></thead>
            <tbody>
              {data.milestones.map((m, i) => (
                <tr key={i}>
                  <td><strong>{m.title}</strong></td>
                  <td>{projectName(m.project)}</td>
                  <td>{m.date}</td>
                  <td>{m.owner}</td>
                  <td><StatusTag s={m.status} /></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </>
  )
}
