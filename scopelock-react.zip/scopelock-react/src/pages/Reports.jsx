import { useStore } from '../store'
import { money, downloadFile, toCSV } from '../utils'
import { PageHead, BarRow } from '../components/ui'

const STATUSES = ['Pending', 'Approved', 'Rejected', 'Deferred', 'Implemented']

export default function Reports() {
  const { data, projectName } = useStore()
  const base = data.projects.reduce((a, p) => a + p.budget, 0)
  const approved = data.changes.filter((c) => c.status === 'Approved').reduce((a, c) => a + c.cost, 0)

  const exportCSV = () => {
    const rows = [
      ['Request', 'Project', 'Requester', 'Cost', 'Days', 'Status'],
      ...data.changes.map((c) => [c.title, projectName(c.project), c.requester, c.cost, c.days, c.status]),
    ]
    downloadFile('scopelock-change-requests.csv', toCSV(rows))
  }

  return (
    <>
      <PageHead title="Reports & analytics" sub="Understand approved scope changes, delivery, and budget movement.">
        <button className="secondary" onClick={exportCSV}>⇩ Export CSV</button>
      </PageHead>

      <div className="grid two">
        <div className="card">
          <div className="card-title"><h2>Change request summary</h2></div>
          {STATUSES.map((s) => {
            const n = data.changes.filter((c) => c.status === s).length
            return <BarRow key={s} label={s} value={n} percent={(n / Math.max(1, data.changes.length)) * 100} />
          })}
        </div>

        <div className="card">
          <div className="card-title"><h2>Budget movement</h2></div>
          <div className="muted" style={{ fontSize: 12 }}>Baseline project value</div>
          <div className="stat-number">{money(base)}</div>
          <div className="muted" style={{ fontSize: 12, marginTop: 12 }}>Approved additional work</div>
          <div className="stat-number" style={{ color: 'var(--green)' }}>+{money(approved)}</div>
          <hr style={{ border: 0, borderTop: '1px solid var(--line)', margin: '16px 0' }} />
          <div className="muted" style={{ fontSize: 12 }}>Revised approved value</div>
          <div className="stat-number">{money(base + approved)}</div>
        </div>
      </div>

      <div className="note" style={{ marginTop: 18 }}>
        Delay attribution should only be assigned when supported by documented records. Demo figures are illustrative and are not production data.
      </div>
    </>
  )
}
