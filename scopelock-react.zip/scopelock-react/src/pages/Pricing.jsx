import { useStore } from '../store'
import { money } from '../utils'
import { StatCard, PageHead, BarRow } from '../components/ui'

export default function Pricing() {
  const { data, toast } = useStore()
  const approved = data.changes.filter((c) => c.status === 'Approved').reduce((a, c) => a + c.cost, 0)
  const pending = data.changes.filter((c) => c.status === 'Pending').reduce((a, c) => a + c.cost, 0)
  const base = data.projects.reduce((a, p) => a + p.budget, 0)
  const maxBudget = Math.max(1, ...data.projects.map((p) => p.budget))

  return (
    <>
      <PageHead title="Pricing & budget" sub="Compare original cost against approved changes only.">
        <button className="secondary" onClick={() => toast('Budget report prepared in demo mode.')}>⇩ Export budget</button>
      </PageHead>

      <div className="grid stats">
        <StatCard label="Original project value" value={money(base)} note="Baseline agreements" />
        <StatCard label="Approved add-ons" value={money(approved)} note="Approved changes only" />
        <StatCard label="Revised total" value={money(base + approved)} note="Baseline + approved additions" />
        <StatCard label="Pending cost impact" value={money(pending)} note="Not included in approved total" />
      </div>

      <div className="card">
        <div className="card-title"><h2>Cost breakdown by project</h2></div>
        {data.projects.map((p) => (
          <BarRow
            key={p.id}
            label={p.name}
            value={money(p.budget)}
            percent={Math.min(100, (p.budget / maxBudget) * 100)}
            labelWidth="minmax(110px,180px)"
            valueWidth="100px"
          />
        ))}
      </div>
    </>
  )
}
