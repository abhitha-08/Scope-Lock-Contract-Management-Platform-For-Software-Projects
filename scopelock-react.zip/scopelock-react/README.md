# ScopeLock (React + Vite)

## Run panna steps (VS Code terminal la)

```bash
npm install
npm run dev
```

Browser la `http://localhost:5173` open pannunga.

## Production build

```bash
npm run build
npm run preview
```

## Folder structure

```
scopelock-react/
├── index.html
├── package.json
├── vite.config.js
└── src/
    ├── main.jsx            # entry point
    ├── App.jsx             # layout + page switch
    ├── store.jsx           # state (Context) + localStorage + all actions
    ├── data.js             # demo seed data
    ├── utils.js            # money format, CSV helpers
    ├── styles.css          # all styles
    ├── components/
    │   ├── Layout.jsx      # Sidebar + Topbar
    │   ├── Modals.jsx      # all modals + toast
    │   └── ui.jsx          # StatusTag, Progress, StatCard, PageHead, BarRow
    └── pages/              # Dashboard, Projects, Scope, Changes, Agreements,
                            # Timeline, Pricing, Reports, Audit, Settings
```

Demo data browser localStorage la save aagum (`scopelock_demo`). Settings > Reset demo data click panna original data vandhudum.
