import test from 'node:test';
import assert from 'node:assert/strict';

const roleCanDecide = role => role === 'MANAGING_DIRECTOR';
const roleCanCreateProject = role => role === 'MANAGING_DIRECTOR';

test('only Managing Director can make final scope decisions', () => {
  for (const role of ['CLIENT','MANAGER','DEVELOPER']) assert.equal(roleCanDecide(role), false);
  assert.equal(roleCanDecide('MANAGING_DIRECTOR'), true);
});
test('only Managing Director can create projects', () => {
  for (const role of ['CLIENT','MANAGER','DEVELOPER']) assert.equal(roleCanCreateProject(role), false);
  assert.equal(roleCanCreateProject('MANAGING_DIRECTOR'), true);
});
test('overlap interval detection rejects intersecting appointment ranges', () => {
  const overlaps=(aStart,aEnd,bStart,bEnd)=>new Date(aStart)<new Date(bEnd)&&new Date(aEnd)>new Date(bStart);
  assert.equal(overlaps('2026-10-20T10:00:00Z','2026-10-20T11:00:00Z','2026-10-20T10:30:00Z','2026-10-20T11:30:00Z'),true);
  assert.equal(overlaps('2026-10-20T10:00:00Z','2026-10-20T11:00:00Z','2026-10-20T11:00:00Z','2026-10-20T12:00:00Z'),false);
});
test('rejected changes should not affect the original price or deadline', () => {
  const original={price:50000,deadline:'2026-12-01'};
  const rejected={status:'REJECTED',additionalCost:9000,timelineImpactDays:12};
  const revised=rejected.status==='APPROVED'?{price:original.price+rejected.additionalCost,deadline:'changed'}:original;
  assert.deepEqual(revised,original);
});
