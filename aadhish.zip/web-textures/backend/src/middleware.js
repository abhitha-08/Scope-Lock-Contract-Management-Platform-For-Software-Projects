import jwt from 'jsonwebtoken';
import { prisma } from './server.js';
export async function requireAuth(req,res,next){
 try {
  const token = req.cookies?.wt_session || req.headers.authorization?.replace(/^Bearer\s+/i,'');
  if(!token) return res.status(401).json({error:'Please sign in.'});
  const payload = jwt.verify(token, process.env.JWT_SECRET);
  const user = await prisma.user.findUnique({where:{id:payload.sub}, select:{id:true,name:true,email:true,role:true,active:true}});
  if(!user?.active) return res.status(401).json({error:'Account unavailable.'});
  req.user = user; next();
 } catch { return res.status(401).json({error:'Session expired. Please sign in again.'}); }
}
export const allow = (...roles)=>(req,res,next)=>roles.includes(req.user?.role) ? next() : res.status(403).json({error:'Your role cannot perform this action.'});
export async function audit(actorId,action,entityType,entityId,projectId,previousValue,newValue,reason){
 return prisma.auditEvent.create({data:{actorId,action,entityType,entityId,projectId,previousValue:previousValue ?? undefined,newValue:newValue ?? undefined,reason}});
}
export async function notify(userIds,title,message,category){
 const ids=[...new Set(userIds.filter(Boolean))]; if(!ids.length)return;
 await prisma.notification.createMany({data:ids.map(userId=>({userId,title,message,category}))});
}
