import { Router } from 'express';
import { prisma } from '../server.js';
import { requireAuth } from '../middleware.js';
const router=Router();router.use(requireAuth);
router.get('/',async(req,res,next)=>{try{const [notifications,unread]=await Promise.all([prisma.notification.findMany({where:{userId:req.user.id},orderBy:{createdAt:'desc'},take:100}),prisma.notification.count({where:{userId:req.user.id,readAt:null}})]);res.json({notifications,unread})}catch(e){next(e)}});
router.patch('/:id/read',async(req,res,next)=>{try{const n=await prisma.notification.findFirst({where:{id:req.params.id,userId:req.user.id}});if(!n)return res.status(404).json({error:'Notification not found.'});const notification=await prisma.notification.update({where:{id:n.id},data:{readAt:n.readAt||new Date()}});res.json({notification})}catch(e){next(e)}});
router.patch('/read-all',async(req,res,next)=>{try{await prisma.notification.updateMany({where:{userId:req.user.id,readAt:null},data:{readAt:new Date()}});res.json({ok:true})}catch(e){next(e)}});
router.get('/audit',async(req,res,next)=>{try{const where=req.user.role==='MANAGING_DIRECTOR'?{}:{projectId:{in:(await prisma.project.findMany({where:req.user.role==='CLIENT'?{clientId:req.user.id}:req.user.role==='MANAGER'?{managerId:req.user.id}:{developerId:req.user.id},select:{id:true}})).map(p=>p.id)}};const events=await prisma.auditEvent.findMany({where,include:{actor:{select:{name:true,role:true}}},orderBy:{createdAt:'desc'},take:250});res.json({events})}catch(e){next(e)}});
export default router;
