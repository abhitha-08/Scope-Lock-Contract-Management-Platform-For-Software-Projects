import { Router } from 'express';
import argon2 from 'argon2';
import jwt from 'jsonwebtoken';
import { z } from 'zod';
import { prisma } from '../server.js';
import { requireAuth, allow, audit } from '../middleware.js';
const router=Router();
const credentials=z.object({email:z.string().email().max(254),password:z.string().min(10).max(128)});
function session(res,user){const token=jwt.sign({sub:user.id,role:user.role},process.env.JWT_SECRET,{expiresIn:'8h'});res.cookie('wt_session',token,{httpOnly:true,secure:process.env.NODE_ENV==='production',sameSite:'lax',maxAge:8*60*60*1000});}
router.post('/register',async(req,res,next)=>{try{
 const body=z.object({name:z.string().min(2).max(100),email:z.string().email(),password:z.string().min(10).max(128)}).parse(req.body);
 const user=await prisma.user.create({data:{...body,email:body.email.toLowerCase(),passwordHash:await argon2.hash(body.password),role:'CLIENT'},select:{id:true,name:true,email:true,role:true}});
 session(res,user);res.status(201).json({user});
}catch(e){if(e.code==='P2002')return res.status(409).json({error:'Email already registered.'});next(e)}});
router.post('/login',async(req,res,next)=>{try{
 const body=credentials.parse(req.body);const found=await prisma.user.findUnique({where:{email:body.email.toLowerCase()}});
 if(!found||!found.active||!(await argon2.verify(found.passwordHash,body.password)))return res.status(401).json({error:'Email or password is incorrect.'});
 const user={id:found.id,name:found.name,email:found.email,role:found.role};session(res,user);res.json({user});
}catch(e){next(e)}});
router.post('/logout',(_req,res)=>{res.clearCookie('wt_session',{httpOnly:true,sameSite:'lax',secure:process.env.NODE_ENV==='production'});res.json({ok:true})});
router.get('/me',requireAuth,(req,res)=>res.json({user:req.user}));
router.post('/bootstrap-director',async(req,res,next)=>{try{
 const body=z.object({setupToken:z.string().min(24),name:z.string().min(2).max(100),email:z.string().email(),password:z.string().min(12).max(128)}).parse(req.body);
 if(!process.env.INITIAL_SETUP_TOKEN || body.setupToken!==process.env.INITIAL_SETUP_TOKEN)return res.status(403).json({error:'Invalid setup token.'});
 if((await prisma.user.count({where:{role:'MANAGING_DIRECTOR'}}))>0)return res.status(409).json({error:'Managing Director has already been initialized.'});
 const user=await prisma.user.create({data:{name:body.name,email:body.email.toLowerCase(),passwordHash:await argon2.hash(body.password),role:'MANAGING_DIRECTOR'},select:{id:true,name:true,email:true,role:true}});
 await audit(user.id,'INITIAL_DIRECTOR_CREATED','USER',user.id,null,null,{role:user.role});session(res,user);res.status(201).json({user});
}catch(e){if(e.code==='P2002')return res.status(409).json({error:'Email already registered.'});next(e)}});
router.post('/invite',requireAuth,allow('MANAGING_DIRECTOR'),async(req,res,next)=>{try{
 const body=z.object({name:z.string().min(2).max(100),email:z.string().email(),password:z.string().min(12).max(128),role:z.enum(['MANAGER','DEVELOPER'])}).parse(req.body);
 const user=await prisma.user.create({data:{...body,email:body.email.toLowerCase(),passwordHash:await argon2.hash(body.password)},select:{id:true,name:true,email:true,role:true}});
 await audit(req.user.id,'TEAM_MEMBER_INVITED','USER',user.id,null,null,{role:user.role});res.status(201).json({user});
}catch(e){if(e.code==='P2002')return res.status(409).json({error:'Email already registered.'});next(e)}});
export default router;
