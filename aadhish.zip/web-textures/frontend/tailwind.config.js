export default {content:['./index.html','./src/**/*.{js,ts,jsx,tsx}'],theme:{extend:{colors:{espresso:'#241914',copper:'#c56d3b',cream:'#f7f0e6'}}},plugins:[]}
