# WEB TEXTURES

AI-Powered Scope Lock & Contract Management Platform — a full-stack hackathon starter with a premium espresso / cream / copper interface, four role-based portals, Express REST API, Prisma/PostgreSQL schema, and workflow tests.

## Features in this build
- Responsive React + Vite + TypeScript UI, theme toggle, animated orb visual, dashboards and empty states.
- Four role portals: Client, Managing Director, Manager, Developer.
- API authentication using Argon2 password hashing and JWT in an HttpOnly cookie; rate-limited login; server-side role middleware.
- Client registration; privileged account invitation; secure initial Managing Director bootstrap using a one-time setup token.
- Project creation (Managing Director only), assigned-project views, change requests, manager review/technical assessment, and Managing Director-only final decision.
- Approval-only price/timeline updates, scope version snapshots, audit events, persistent notifications, appointment slot and booking endpoints with overlap checks, agreement records.
- Prisma models and initial migration workflow, environment template, tests for permission boundaries.

> This is a functional MVP foundation, not a legal e-signature service or a production security certification. PDF generation, external e-signature provider, WebSocket delivery and cloud object storage need provider credentials/configuration before production. The UI clearly labels the agreement acceptance workflow and does not claim a button click is a legally valid signature.

## Requirements
- Node.js 20+
- PostgreSQL 15+

## Local setup
1. Copy `.env.example` to `backend/.env` and fill in values. Generate secrets; do not commit `.env`.
2. From the repository root run `npm install`.
3. Run `npm install --prefix backend` and `npm install --prefix frontend`.
4. Run `npm run db:generate --prefix backend` then `npm run db:migrate --prefix backend`.
5. Start both apps with `npm run dev`.
6. Frontend runs at `http://localhost:5173`; API runs at `http://localhost:4000`.

## Create the first Managing Director
Set `INITIAL_SETUP_TOKEN` in `backend/.env` to a long random value. Make a POST to `/api/auth/bootstrap-director` with `{ "setupToken": "...", "name": "...", "email": "...", "password": "..." }`. This endpoint is disabled after the first Managing Director exists. Do not expose the setup token publicly. Then log in through the Managing Director portal.

## Invite team members
A Managing Director can call `POST /api/auth/invite` with `{name,email,password,role}` for `MANAGER` or `DEVELOPER`. For production, replace password-based invitation with expiring single-use invitation links.

## Test and build
- `npm test --prefix backend`
- `npm run build --prefix frontend`

## Security notes before deployment
- Set `NODE_ENV=production`, use HTTPS, a managed PostgreSQL instance, strong JWT/setup secrets, and a restricted CORS origin.
- Configure secure object storage and malware scanning for uploaded files before enabling uploads.
- Add an external e-signature provider if legally enforceable electronic signatures are required.
- Add operational logging, backups, monitoring, dependency updates, and independent security review.
